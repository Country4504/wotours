# MongoDB数据库分享包

## 数据库信息
- **数据库名**: natours-test
- **备份时间**: 2025-10-23 03:06:48
- **备份大小**: 12K

## 快速导入

### Linux/Mac用户
```bash
# 1. 解压分享包
tar -xzf natours-test_share_package.tar.gz
cd share_package

# 2. 一键导入
./quick_import.sh natours-test natours-test_backup.tar.gz
```

### Windows用户
```cmd
# 1. 解压分享包
# 2. 运行导入脚本
quick_import.bat
```

## 数据库结构
- tours: 9 文档
- reviews: 52 文档
- users: 21 文档

## 导入后验证
```bash
# 连接数据库
mongosh natours-test

# 查看集合
show collections

# 查看数据条数
db.集合名.count()
```

## 注意事项
- 确保MongoDB已安装并运行
- 需要数据库写入权限
- 导入前备份现有数据（如果存在同名数据库）

---
由 MongoDB分享工具生成
