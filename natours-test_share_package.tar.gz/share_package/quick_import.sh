#!/bin/bash

# MongoDB快速导入脚本
# 使用方法: ./quick_import.sh <数据库名> [备份文件路径]

DB_NAME=${1:-"default_database"}
BACKUP_FILE=${2:-"database_backup.tar.gz"}

echo "=========================================="
echo "  MongoDB 数据库快速导入工具"
echo "=========================================="
echo "数据库名: $DB_NAME"
echo "备份文件: $BACKUP_FILE"
echo "=========================================="

# 检查MongoDB是否运行
echo "检查MongoDB服务状态..."
if ! mongosh --version > /dev/null 2>&1; then
    echo "错误: MongoDB未安装或未在PATH中"
    echo "请先安装MongoDB"
    exit 1
fi

# 检查备份文件是否存在
if [ ! -f "$BACKUP_FILE" ]; then
    echo "错误: 备份文件 $BACKUP_FILE 不存在"
    echo "请确保备份文件在当前目录中"
    exit 1
fi

# 创建临时目录
TEMP_DIR="/tmp/mongo_import_$$"
mkdir -p $TEMP_DIR

echo "正在解压备份文件..."
tar -xzf $BACKUP_FILE -C $TEMP_DIR

# 查找解压后的数据库目录
DB_DIR=$(find $TEMP_DIR -type d -name "$DB_NAME" | head -1)

if [ -z "$DB_DIR" ]; then
    echo "警告: 未找到数据库名为 $DB_NAME 的目录"
    echo "尝试查找第一个可用数据库..."
    DB_DIR=$(find $TEMP_DIR -type d -name "*" | head -2 | tail -1)
    if [ -z "$DB_DIR" ]; then
        echo "错误: 未找到有效的数据库目录"
        rm -rf $TEMP_DIR
        exit 1
    fi
fi

echo "正在导入数据库 $DB_NAME..."
"/c/Program Files/MongoDB/Tools/100/bin/mongorestore.exe" --db $DB_NAME $DB_DIR

# 清理临时文件
rm -rf $TEMP_DIR

echo "=========================================="
echo "✅ 数据库导入完成!"
echo "导入的数据库名: $DB_NAME"
echo "=========================================="

# 显示数据库信息
echo ""
echo "数据库信息:"
echo "集合列表:"
mongosh $DB_NAME --eval "db.getCollectionNames().forEach(function(name){print('- ' + name)});" --quiet

echo ""
echo "文档总数:"
mongosh $DB_NAME --eval "var count = 0; db.getCollectionNames().forEach(function(name){count += db[name].countDocuments()}); print('总文档数: ' + count);" --quiet